from datetime import date

from django.http import HttpResponse
from django.shortcuts import render


def hello_world(request):
    return HttpResponse("<h1>Hello World</h1>")


def greet(request, name):
    return HttpResponse(f"<h1>Welcome <b>{name}!</b></h1>")


def add_two_numbers(request, a, b):
    try:
        result = int(a) + int(b)
    except ValueError:
        return HttpResponse(f"<h1>Invalid argument in url, must be integer</h1>")
    return HttpResponse(f"<h1>{a} + {b} = {result}</h1>")


def render_html_file(request):
    return render(request, "first_app/first_template.html")


def render_html_file_with_context(request):
    week_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    another_person = {"name1": "Jane", "last_name1": "Another Doe"}
    ctx = {
        "name": "John",
        "last_name": "Doe",
        "week_days": week_days,
        "another_person": another_person,
    }

    return render(request, "first_app/template_with_ctx.html", context=ctx)


"""
Chcemy zrobić widok który w url będzie dostawał dwie liczby, 
a następnie w templatce wyświetli nam się dzisiejsza data oraz lista liczb parzystych w zakresie liczb podanych w url
"""


def even_numbers(request, a, b):
    today_date = date.today()
    start = a
    end = b
    if a > b:
        start = b
        end = a
    even_nrs = [number for number in range(start, end) if number % 2 == 0]
    ctx = {
        "start": start,
        "end": end,
        "today_date": today_date,
        "even_nrs": even_nrs,
    }

    return render(request, "first_app/even_nrs.html", context=ctx)
