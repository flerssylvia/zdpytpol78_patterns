from django.contrib import admin

from inventory.models import Item


admin.site.register(Item)
