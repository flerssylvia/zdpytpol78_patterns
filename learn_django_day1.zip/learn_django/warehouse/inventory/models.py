from django.db import models


class Item(models.Model):
    name = models.CharField(max_length=100)
    amount = models.PositiveIntegerField()
    value = models.FloatField()  # Docelowo do pieniędzy chcemy Decimal
    manufacturer = models.CharField(max_length=100)
    category = models.CharField(max_length=100)

    def __str__(self):
        return f"Item: {self.name}"
