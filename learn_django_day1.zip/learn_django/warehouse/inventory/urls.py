from django.urls import path

from inventory.views import item_list

urlpatterns = [
    path("list", item_list),
]
