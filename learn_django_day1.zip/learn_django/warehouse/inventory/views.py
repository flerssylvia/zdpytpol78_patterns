from django.shortcuts import render

from inventory.models import Item


def item_list(request):
    items = Item.objects.all()  # Query ORM djangowego, aby wyciągnąć wszystkie elementy danej klasy
    ctx = {
        "items": items,
    }

    return render(request, "inventory/item_list.html", context=ctx)
